/** code by Jintao Wang in U Tennessee**/
 
// corr.h
// Simple header that prevents re-definition
#ifndef WJT_CORRELATION_H
#define WJT_CORRELATION_H

// Include Headers
#include <iostream>
#include <fstream>
#include <cstdio>
#include <vector>
#include <string>
#include <cstdlib>
#include <cmath>

#define DEFAULT_PERMU_NUM 5000

using namespace std;

int compare_doubles (const void * a, const void * b);
vector<double>  permutation(vector<double>  B);
double calCorrelation(vector<double> A, vector<double> B);
void stringSplit(const string& str,
                      vector<string>& tokens,
                      const string& delimiterSet  = ";\t, ");
#endif // WJT_CORRELATION_H


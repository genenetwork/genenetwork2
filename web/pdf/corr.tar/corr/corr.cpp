/*****************************************************
corr.cpp -- Correlation Calculation 
Copyright (C) 2002 Kenneth F. Manly 

This program is free software; you can redistribute it and/or modify it 
under the terms of the GNU General Public License as published by the 
Free Software Foundation; either version 2 of the License, or (at your 
option) any later version. See http://www.gnu.org/licenses/gpl.txt. 

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU 
General Public License for more details. 

You should have received a copy of the GNU General Public License along 
with this program; if not, write to the Free Software Foundation, Inc., 
59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA 

Kenneth F. Manly, Molecular & Cellular Biology, Roswell Park Cancer 
Institute, Buffalo, NY 14263-0001 
kenneth.manly@roswellpark.org 

*****************************************************/

/** code by Jintao Wang in U Tennessee**/


#include "corr.h"

int main(int argc, char* argv[]) {
	int i,j, npermu;
	double oriCorr;
	bool k;
	char *pFilename;
	string readLine;
	vector<string> subStrings;
	
	string flag;
	bool dispAll = false;
	int argi = 1;
	
	vector<double> A;
	vector<double> B, C;
	cout << "Calculate correlation permutation : \n";
	
	// Strip leading -A from the command line.
	flag = "-A";
	if ( argv[argi] == flag) {
		dispAll = true;
		++argi;
	}
	
	if (argi < argc)
		pFilename = argv[argi];
	else{
		cout << "No input file provided" << endl;
		return 0;
	}
	argi++;
	
	
	if (argi < argc){
		npermu = atoi(argv[argi]);
		if (npermu <= 0)
			npermu = DEFAULT_PERMU_NUM;
	}
	else
		npermu = DEFAULT_PERMU_NUM;
	
	
	cout << "File name: " << pFilename << endl;
	cout << "# of permutations: " << npermu << endl;
	ifstream in(pFilename);
	if (in == NULL){
		cout << "The file \""<< pFilename << "\" doesn't exist." << endl;
		return 0;
	}
	
	//Read Data A
	getline(in,readLine);
	while (readLine[0] == '#'){
		getline(in,readLine);
	}
	
	stringSplit(readLine, subStrings);
	for (i=0;i< subStrings.size();i++){
		//cout << subStrings[i] << endl;
		A.push_back(atof(subStrings[i].c_str()));
	}
	
	//Read Data B
	getline(in,readLine);
	while (readLine[0] == '#'){
		getline(in,readLine);
	}
	subStrings.clear();
	stringSplit(readLine, subStrings);
	for (i=0;i< subStrings.size();i++){
		//cout << subStrings[i] << endl;
		B.push_back(atof(subStrings[i].c_str()));
	}
	if (A.size() != B.size()){
		cout << "The two sets of data don't have same number of values." << endl;
		return 0;
	}
	
	cout << "Trait 1\t";
	for (i=0; i < A.size(); i++)
		cout << A[i] << " ";
	cout << "\n";
	
	cout << "Trait 2\t";
	for (i=0; i < B.size(); i++)
		cout << B[i] << " ";
	cout << "\n";
	
  	srand(time(NULL));
  	double *List = new double[npermu];
  	oriCorr = calCorrelation(A, B);
	cout << "original\t" << oriCorr << endl;
	for (i=0;i< npermu; i++){
		C = permutation(B);
		List[i] = calCorrelation(A, C);
		if (dispAll) 
			cout << i+1 << "\t" << List[i] << endl;
	}
	qsort(List, npermu, sizeof(double),compare_doubles);
	
	int rank = 0;
	for (i=0;i< npermu; i++){
		rank = i;
		if (List[i] >= oriCorr){
			break;
		}
	}
	
	cout << "\n\n#######\nResult\n#######\n";
	cout << "original\t" << oriCorr << "\tp = " <<  1.0 - (rank+0.0)/npermu << endl;
	cout << "95%\t" << List[int(npermu*0.95)-1] << "\tp = 0.05"  << endl;
	cout << "99%\t" << List[int(npermu*0.99)-1] << "\tp = 0.01"  << endl;
	
	delete[] List;	
	return 1;
	
}

void stringSplit(const string& str,
                      vector<string>& tokens,
                      const string& delimiterSet)
{   
    int i, j;
    bool k = false;
    string delimiters;
    for (i=0;i< str.size();i++){
        for (j=0;j < delimiterSet.size();j++){
            if (str[i] == delimiterSet[j]){
                delimiters = str[i];
                k = true;
                break;
            }
        }
        if (k)
            break;
    }
    
    // Skip delimiters at beginning.
    string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    // Find first "non-delimiter".
    string::size_type pos     = str.find_first_of(delimiters, lastPos);

    while (string::npos != pos || string::npos != lastPos)
    {
        // Found a token, add it to the vector.
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        // Skip delimiters.  Note the "not_of"
        lastPos = str.find_first_not_of(delimiters, pos);
        // Find next "non-delimiter"
        pos = str.find_first_of(delimiters, lastPos);
    }
}

vector<double>  permutation(vector<double>  B)
{	
	int i,j, N;
	double temp;
	vector<double> C;
	
	N = B.size();
	for (i = 0; i < N; i++)
		C.push_back(B[i]);
		
	for (i = N-1;i > 0;i--)
	{
		j =rand() % (i+1);
		temp = C[i];
		C[i] = C[j];
		C[j] = temp;
	}
	return C;
}

double calCorrelation(vector<double> A, vector<double> B){
	int NN, i;
	double sA, sB, meanA, meanB;
	double ABd, sAd, sBd;
	if (A.size() != B.size())
		return 0.0;
	else
		NN = A.size();
		
	if (NN <6)
		return 0.0;
	sA = sB = 0.0;
	for (i=0;i < NN; i++){
		sA += A[i];
		sB += B[i];
	}
	meanA = sA/NN;
	meanB = sB/NN;
	
	ABd = 0.0;
	sAd = 0.0;
	sBd = 0.0;
	for (i=0;i < NN; i++){
		ABd += (A[i] - meanA)*(B[i]-meanB);
		sAd += (A[i] - meanA)*(A[i] - meanA);
		sBd += (B[i] - meanB)*(B[i] - meanB);
	}
	
	return ABd/(sqrt(sAd)*sqrt(sBd));
}

/*****************************************************
 * Method function for comparing two doubles
 *****************************************************/

int compare_doubles (const void * a, const void * b)
{
	/*double temp = *((double *)a) - *((double *)b);
	if (temp > 0)
		return 1;
	else if (temp < 0)
		return -1;
	else
		return 0;*/
	const double *da = (const double *)a;
	const double *db = (const double *)b;
	return (*da > *db)-(*da < *db);
}


